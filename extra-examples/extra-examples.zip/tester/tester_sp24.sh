#!/bin/bash

cd files
python tester_sp24.py
