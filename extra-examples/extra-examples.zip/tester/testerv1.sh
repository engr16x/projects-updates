#!/bin/bash

cd files
python tester.py
