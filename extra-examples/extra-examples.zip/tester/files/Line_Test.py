import grovepi
import time
import cmdgui

def Line_Test():
        result = ['Line_Test']

        linestage = cmdgui.stage(title = 'Line Test',width = 60, height = 15)
        cmdgui.setstage(linestage)

        cmdgui.writeline(linestage,'Grove Line will Read for 5s, move on and off line!',1)

        zerovalue = False
        onevalue = False
        error = False

        # Connect the Grove Line Finder to digital port D7
        # SIG,NC,VCC,GND
        line_finder = 7

        grovepi.pinMode(line_finder,"INPUT")

        for i in range(10):
            try:
                readval = grovepi.digitalRead(line_finder)
            except IOError:
                error = True

            if (readval == 0):
                zerovalue = True
            else:
                onevalue = True

            cmdgui.writeline(linestage,'Line: '+ str(readval),3)
            
            time.sleep(0.25)

        if zerovalue and onevalue and not error:
            cmdgui.writeline(linestage,'Both values returned, good!',5)
            result.append('PASSED')
        else:
            cmdgui.writeline(linestage,'ERROR: issue detected',5)
            result.append('FAILED')
        cmdgui.writeline(linestage,str(result[0]+": " + result[1]),6)
        time.sleep(1)
        return(result)
