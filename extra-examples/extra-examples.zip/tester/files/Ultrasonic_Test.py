import grovepi
import time
import cmdgui

def Ultrasonic_Test():
        result = ['Grove_Ultrasonic_Test']

        ultrasonicstage = cmdgui.stage(title = 'GroveUltra Test',width = 60, height = 15)
        cmdgui.setstage(ultrasonicstage)

        cmdgui.writeline(ultrasonicstage,'Grove Ultrasonic will Read for 5s, wave your hand over it!',1)

        zerovalue = False

        grovepi.set_bus("RPI_1")
        ultrasonic_ranger = 4

        for i in range(10):

            readval = grovepi.ultrasonicRead(ultrasonic_ranger)

            if (readval == 0):
                zerovalue = True

            cmdgui.writeline(ultrasonicstage,'Distance: '+ str(readval),3)
            
            time.sleep(0.25)

        if zerovalue:
                cmdgui.writeline(ultrasonicstage,'ERROR: zero value detected',5)
                result.append('FAILED')
        else:
                cmdgui.writeline(ultrasonicstage,'Non-zero values returned, good!',5)
                result.append('PASSED')
        cmdgui.writeline(ultrasonicstage,str(result[0]+": " + result[1]),6)
        time.sleep(1)
        return(result)
