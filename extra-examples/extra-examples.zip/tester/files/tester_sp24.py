#No line sensors - DONE
#Add IR sensor
#Change motor duration - DONE (note this is applied in the BPMotor_Test.py file and as such applies to the V1 testfile too)

import grovepi
import brickpi3
import sys
import time

import cmdgui
from IMU_Test import *
from Ultrasonic_Test import *
from BPButton_Test import *
from BPMotor_Test import *
from GroveIR_Test import *
from printresults import *

if __name__ == "__main__":
        try:
                testresults = []
                testresults.append(IMU_Test())
                testresults.append(Ultrasonic_Test())
                testresults.append(GroveIR_Test())
                testresults.append(BPButton_Test())
                testresults.append(BPMotor_Test())

                printresults(testresults)

                while True:
                        if KeyboardInterrupt:
                                sys.exit

        except KeyboardInterrupt:
                sys.exit()

