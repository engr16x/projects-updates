import brickpi3
import time
import cmdgui

#https://tldp.org/HOWTO/Bash-Prompt-HOWTO/x361.html
def BPButton_Test():
        result = ['BPButton_Test']
        
        bpmotorstage = cmdgui.stage(title = 'BrickPi Button Test',width = 60, height = 15)
        cmdgui.setstage(bpmotorstage)
        
        zerovalue = True

        BP = brickpi3.BrickPi3()
        BP.set_sensor_type(BP.PORT_1, BP.SENSOR_TYPE.TOUCH)
        time.sleep(0.25)

        starttime = time.time()

        cmdgui.writeline(bpmotorstage,'Press the button. Test will time out in 5 seconds.',1)

        temp = 0
        
        while True:
                if (time.time() - starttime)>temp:
                        cmdgui.writeline(bpmotorstage,"Timeout in %1d" % int(5 - (time.time() - starttime)),3)
                        temp += 1

                if BP.get_sensor(BP.PORT_1) != 0:
                        zerovalue = False
                        cmdgui.writeline(bpmotorstage,'boop!',4)
                        break
                elif time.time() - starttime > 5:
                        cmdgui.writeline(bpmotorstage,'Timed Out :(',4)
                        break

        if zerovalue:
                cmdgui.writeline(bpmotorstage,"ERROR: zero value detected",6)
                result.append('FAILED')
        else:
                cmdgui.writeline(bpmotorstage,"Non-zero values returned, good!",6)
                result.append('PASSED')
        cmdgui.writeline(bpmotorstage,str(result[0]+": " + result[1]),7)
        time.sleep(1)
        return(result)
