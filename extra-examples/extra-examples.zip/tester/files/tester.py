import grovepi
import brickpi3
import sys
import time

import cmdgui
from IMU_Test import *
from Ultrasonic_Test import *
from Line_Test import *
from BPButton_Test import *
from BPUltrasonic_Test import *
from BPColor_Test import *
from BPMotor_Test import *
from printresults import *

if __name__ == "__main__":
        try:
                testresults = []
                testresults.append(IMU_Test())
                testresults.append(Ultrasonic_Test())
                testresults.append(Line_Test())
                testresults.append(BPButton_Test())
                testresults.append(BPUltrasonic_Test())
                #testresults.append(BPColor_Test())
                testresults.append(BPMotor_Test())

                printresults(testresults)

                while True:
                        if KeyboardInterrupt:
                                sys.exit

        except KeyboardInterrupt:
                sys.exit()

