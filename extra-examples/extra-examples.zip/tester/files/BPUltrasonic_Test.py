import brickpi3
import time
import cmdgui

#https://tldp.org/HOWTO/Bash-Prompt-HOWTO/x361.html
def BPUltrasonic_Test():
        result = ['BPUltrasonic_Test']
        
        bpultrasonicstage = cmdgui.stage(title = 'BrickPi Ultrasonic Test',width = 60, height = 15)
        cmdgui.setstage(bpultrasonicstage)
        
        zerovalue = True

        BP = brickpi3.BrickPi3()
        BP.set_sensor_type(BP.PORT_4, BP.SENSOR_TYPE.NXT_ULTRASONIC)
        time.sleep(0.25)

        starttime = time.time()

        cmdgui.writeline(bpultrasonicstage,'BP Ultrasonic will Read for 5s, wave your hand over it!',1)

        zerovalue = False

        for i in range(10):
            try:
                readval = BP.get_sensor(BP.PORT_4)
            except brickpi3.SensorError as err:
                print(err)

            if (readval == 0):
                zerovalue = True

            cmdgui.writeline(bpultrasonicstage,'Distance: '+ str(readval),3)
            
            time.sleep(0.25)

        if zerovalue:
                cmdgui.writeline(bpultrasonicstage,"ERROR: zero value detected",6)
                result.append('FAILED')
        else:
                cmdgui.writeline(bpultrasonicstage,"Non-zero values returned, good!",6)
                result.append('PASSED')
        cmdgui.writeline(bpultrasonicstage,str(result[0]+": " + result[1]),7)
        time.sleep(1)
        return(result)
