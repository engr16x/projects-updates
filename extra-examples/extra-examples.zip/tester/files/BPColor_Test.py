import brickpi3
import time
import cmdgui

#https://tldp.org/HOWTO/Bash-Prompt-HOWTO/x361.html
def BPColor_Test():
        result = ['BPColor_Test']
        
        bpcolorstage = cmdgui.stage(title = 'BrickPi Color Test',width = 60, height = 15)
        cmdgui.setstage(bpcolorstage)
        
        zerovalue = True

        BP = brickpi3.BrickPi3()
        BP.set_sensor_type(BP.PORT_1, BP.SENSOR_TYPE.EV3_COLOR_COLOR)
        color = ["none", "Black", "Blue", "Green", "Yellow", "Red", "White", "Brown"]
        time.sleep(0.25)

        starttime = time.time()

        cmdgui.writeline(bpcolorstage,'BP Color will Read for 5s, wave it over a colored surface!',1)

        zerovalue = False
        error = False
        bperror = ""

        for i in range(10):
            try:
                readval = BP.get_sensor(BP.PORT_1)
            except brickpi3.SensorError as bperror:
                error = True

            if (readval == 0):
                zerovalue = True

            cmdgui.writeline(colorstage,'Color: '+ color[readval],3)
            
            time.sleep(0.25)

        if zerovalue:
                cmdgui.writeline(bpcolorstage,"ERROR: zero value detected",6)
                result.append('FAILED')
        elif error:
                cmdgui.writeline(bpcolorstage,"ERROR:" + str(bperror),6)
        else:
                cmdgui.writeline(bpcolorstage,"Non-zero values returned, good!",6)
                result.append('PASSED')
        cmdgui.writeline(bpcolorstage,str(result[0]+": " + result[1]),7)
        time.sleep(1)
        return(result)
